Multiplayer Read Me Text

- SOUND EFFECTS AND BACKGROUND MUSIC IS INCLUDED - TURN ON YOUR SPEAKERS

- The multiplayer game file may take up to 10 seconds or more to load, 
depending on the speed of your computer.

- Currently, maps templates can be found in the "resources" folder in "mapDataBase.txt". Additionally maps may be added by adding text in that file while following the protocol stated at the beginning of the file if you wish. It is not guaranteed that the added map will work with the game, even if the protocol is followed. It is advised that you use the maps included with the game.

- Power up legend:
	- Lighting bolt -> increase speed
	- Bullet with infinity symbol -> infinted ammo for 10 sec
	- Bullet with lighting bolt -> stronger ammo for 10 sec
	- Heart -> double life
- Power ups will spawn randomly and will disappear automatically after 20 sec if unclaimed

- Amount of ammo and health left for each tank is displayed on the top bar

- If an error occurs, please ensure that the "resources" folder is in the same directory as this file (the resources folder, not the contents of the folder)

- Full Screen Detector at the Beginning of the Game:
	- Pygame will try to detect the resolution of your screen and will display some images and text according to the resolution it 	displayed
	- If the displayed content appears distorted in any way, press "NO" (pygame detected the resolution wrong and the game 	graphics will not appear properly if the game ran in full screen, the game will now run in a window. Pressing the close button
	at any time will close the game)
	- If the displayed content does NOT appear distorted, then full screen should work! The game will run in full screen mode, 		which can be exited by pressing the quit or main menu button in the pause menu when the game begins
	- Screen modes can be switched by closing the game and reopening it

- If you do not understand any part of the game, a blue help button is included in the majority of the screens where confusing content
may be displayed. Mousing over the button will open up the help content.