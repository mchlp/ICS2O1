Samuel Liu & Michael Pu
ICS2O
Final Project - Tank Wars

Division of Work:
Menu - Samuel
Single Player Mode - Samuel
Multi Player Mode - Michael

- to run the game: runGame.bat

ignore the "libpng warning: iCCP: known incorrect sRGB profile", the game should still work fine

IF IT DOESN'T WORK: try running the Tank_Wars.py file directly instead of running it through the z-runGame.bat file